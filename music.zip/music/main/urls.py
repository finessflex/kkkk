﻿from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('genres/', views.genres, name='genres'),
    path('tracks/', views.tracks, name='tracks'),
]
