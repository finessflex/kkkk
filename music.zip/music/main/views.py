﻿from django.shortcuts import render
from .models import Genre, Track


def index(request):
    return render(request, 'main/index.html')


def genres(request):
    genres_list = Genre.objects.all()
    return render(request, "main/genres.html", {"genres": genres_list})


def tracks(request):
    tracks_list = Track.objects.prefetch_related("genres").all()
    return render(request, "main/tracks.html", {"tracks": tracks_list})
